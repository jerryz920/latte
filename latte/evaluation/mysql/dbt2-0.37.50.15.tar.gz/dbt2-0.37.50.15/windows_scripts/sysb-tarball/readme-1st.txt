Before running the script, please rename sysbench.cluster/sysbench.server to sysbench.conf.
Mind that this configuration was used to test on 512GM RAM/48 physical cores server!